package application;

import java.awt.Color;
import java.awt.Font;
import java.util.Arrays;
import java.util.HashMap;
import org.apache.commons.lang3.ArrayUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.BoxAndWhiskerToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;


import weka.core.Instances;


public class BoxPlotChart {
	  //private static final LogContext LOGGER = Log.createContext(BoxPlotChart.class);	
	  private static int start=0;
	  private static int visible=4;
	  private static BoxAndWhiskerCategoryDataset dataset;
	  private static CategoryPlot plot;
	  public static JFreeChart generateBoxPlotChart(Instances data) {
	      dataset = createSampleDataset(data,start);
	      final CategoryAxis xAxis = new CategoryAxis("Attributes");
	      final NumberAxis yAxis = new NumberAxis("Frequency");
	      yAxis.setAutoRangeIncludesZero(false);
	      final BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
	      //change the width of the wisker:
	      renderer.setWhiskerWidth(0.5);
	      //change the width of the bar:
	      renderer.setMaximumBarWidth(0.05);
	      renderer.setFillBox(true);
	      renderer.setSeriesPaint(1, Color.red);
	     // renderer.setSeriesPaint(0, Color.blue);
	      renderer.setSeriesOutlinePaint(1, Color.darkGray);
	    //  renderer.setSeriesOutlinePaint(0, Color.yellow);
	      renderer.setUseOutlinePaintForWhiskers(true);   
	      Font legendFont = new Font("SansSerif", Font.PLAIN, 16);
	      renderer.setLegendTextFont(1, legendFont);
	      //renderer.setLegendTextFont(1, legendFont);
	      renderer.setMedianVisible(true);
	      renderer.setMeanVisible(false);
	     /// renderer.setFillBox(false);
	      renderer.setDefaultToolTipGenerator(new BoxAndWhiskerToolTipGenerator());
	      plot= new CategoryPlot(dataset, xAxis, yAxis, renderer);

	      final JFreeChart chart = new JFreeChart(
	          "BoxPlot",
	          new Font("Bauhaus 93", Font.BOLD, 19),
	          plot,
	          true
	      );
	        
		    return chart;
		    }  	
	
	
     public static BoxAndWhiskerCategoryDataset createSampleDataset(Instances data,int start) {   
        final int seriesCount =1;
        final int categoryCount =data.numAttributes();
        final int entityCount = data.numInstances();//data.numInstances();       
        final DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
       for (int i = start; i < start+visible; i++) {
    	         Double[] d = ArrayUtils.toObject(data.attributeToDoubleArray(i));    	         
    	         HashMap<String,Double[]> test = new HashMap<String,Double[]>();
                 test.put(data.attribute(i).name(),d);
                 dataset.add(Arrays.asList(test.get(data.attribute(i).name())),"", data.attribute(i).name());
        }
        return dataset; 
        }
     
     public static void BoxplotPrev(Instances data) {
         start -= visible;
         if (start < 0) {
             start = 0;
           //  return;
         }
         dataset=createSampleDataset(data,start);
         plot.setDataset(dataset);
     }
     
     
     public static void BoxplotNext(Instances data) {
         start += visible;
         int var=data.numAttributes()-1 - visible;
         if (start > var) {
             start = var;
            // return;
         }
         dataset=createSampleDataset(data,start);
         plot.setDataset(dataset);
     }
}
