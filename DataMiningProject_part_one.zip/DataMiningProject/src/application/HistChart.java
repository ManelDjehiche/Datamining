package application;
import java.util.Arrays;
import java.util.HashMap;

import javafx.scene.chart.XYChart;
import weka.core.Instances;

public class HistChart {
	private static int nbSubranges=5;
	
public static  XYChart.Series createHist(Instances data,int index){
	XYChart.Series series=new XYChart.Series();
	double[] attData=data.attributeToDoubleArray(index);
	switch (index){
	case 0:
	case 3:
	case 4:
	case 7:
	case 9:
	case 11:{System.out.println(data.attribute(index).name()+" *** is numeric");
	double[] limitValues=new double[nbSubranges+1];
    double max = Arrays.stream(attData).max().getAsDouble();
    double min = Arrays.stream(attData).min().getAsDouble();
    double range_width=(max-min)/nbSubranges;
    double q=min;
    for(int i=0;i<nbSubranges;i++){
    	limitValues[i]=q;
    	q+=range_width;
    }
    limitValues[nbSubranges]=max;
    for(int i=0;i<nbSubranges;i++){//attData,limitValues[i]+"-"+limitValues[i+1]  //frequency(attData,limitValues[i],limitValues[i+1])
    	series.getData().add(new XYChart.Data<>((int)limitValues[i]+"-"+(int)limitValues[i+1],frequency(attData,limitValues[i],limitValues[i+1])));
    }   
	};break;
	default: {
		System.out.println(data.attribute(index).name()+" ----- is not numeric");
		HashMap<String,Integer> test = new HashMap<String,Integer>();
		 int length=data.numInstances();
        for(int i=0;i<length;i++)//new Integer(test.get(String.valueOf((int)d[i]))+1)
       	   if (test.get(String.valueOf((int)attData[i]))==null) test.put(String.valueOf((int)attData[i]),new Integer(1));
       	   else{	   
		       test.put(String.valueOf((int)attData[i]),new Integer(test.get(String.valueOf((int)attData[i]))+1));
       	   }
        for(String i:test.keySet()){
       	// System.out.println(i+":"+test.get(i));
     	series.getData().add(new XYChart.Data<>(i,test.get(i)));
        }					
	}
	}
	return(series);
}

public static int frequency(double[] attData, double min , double max){
	int freq=0;
	int i=0,length=attData.length;
	Arrays.sort(attData);
	while((i<length)&&(attData[i]<min)) i++;
	if(i<length){
		while((i<length)&&(attData[i]<=max)) {
			i++;
			freq++;
		}
	}
	return freq;
}
}
