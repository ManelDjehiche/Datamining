package application;

import java.util.ArrayList;
import java.util.Hashtable;

public class Rule {
	
	private String gauche;
	private ArrayList<String> droite;
	private double confidence;
	private int supp_gauche;
	private int supp_father;

	
    
	public Rule(String gauche, ArrayList<String> droite, int supp_gauche, int supp_doirte) {
		super();
		this.gauche = gauche;
		this.droite = droite;
		this.supp_gauche = supp_gauche;
		this.supp_father = supp_doirte;
		this.confidence=(float)((double)this.supp_father*100/(double)this.supp_gauche);
		
	}

	public String getGauche() {
		return gauche;
	}

	public void setGauche(String gauche) {
		this.gauche = gauche;
	}

	public ArrayList<String> getDroite() {
		return droite;
	}

	public void setDroite(ArrayList<String> droite) {
		this.droite = droite;
	}

	public double getConfidence() {
		return confidence;
	}

	public void setConfidence(double confidence) {
		this.confidence = confidence;
	}

	public int getSupp_gauche() {
		return supp_gauche;
	}

	public void setSupp_gauche(int supp_gauche) {
		this.supp_gauche = supp_gauche;
	}

	public int getSupp_doirte() {
		return supp_father;
	}

	public void setSupp_doirte(int supp_doirte) {
		this.supp_father = supp_doirte;
	}	
	
//	
//    public static void main(String[]args) {
//    	final int[]  a = {1,2,3,4,15};
//    	int[] b=new int[5];
//    	for(int i=0;i<b.length;i++)b[i]=a[i];
//    	b=a;
//    	a[1]=7;
//    	System.out.println(b[3]+"  "+a[1]);
//    }
}
