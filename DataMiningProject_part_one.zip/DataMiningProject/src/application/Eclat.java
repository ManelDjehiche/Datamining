package application;

import java.beans.XMLEncoder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;

import weka.core.Instances;

public class Eclat {
	
	private int min_support;
	private int max_set_size;
	private int nb_condidates;
	private int ass_cond;
	private double min_confidence;
	private String[][] dataset;
	private Hashtable<Integer,Hashtable<String, ArrayList<Integer>>> L=new Hashtable<Integer,Hashtable<String, ArrayList<Integer>>>(); //dic.put(S,o);  //o=dic.get(S); return object   //Integer I=(Integer)dic.get("deux");
	private Hashtable<String,Association> association=new  Hashtable<String,Association>(); // key est le condidate frequent dans dataset, et lobject association coontient touts les regles d'association de ce condidat
    private Instances data;
	private Dataset d;
	public Eclat(int min_support, double min_confidence,int max_set_size,int nb_condidates,int ass_cond,Instances data) {
		super();
		this.max_set_size=max_set_size;
		this.nb_condidates=nb_condidates;
		this.ass_cond=ass_cond;
		this.min_support = min_support;
		this.min_confidence = min_confidence;
		this.data=data;
		d=new Dataset(data);
		String[][]table =d.getDataset_table();
		this.dataset=new String[table.length][table[0].length];
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].length;j++) {
				this.dataset[i][j]=table[i][j];
			}
		}		
	}
	public Hashtable<String, Association> getAssociation() {
		return association;
	}
	public void setAssociation(String key,Association association) {
		this.association.put(key,association);
	}
	public void setL(Hashtable<String, ArrayList<Integer>> l,Integer key) {
		L.put(key,l);
	}
	public int getMin_support() {
		return min_support;
	}

	public void setMin_support(int min_support) {
		this.min_support = min_support;
	}
	public double getMin_confidence() {
		return min_confidence;
	}
	public void setMin_confidence(double min_confidence) {
		this.min_confidence = min_confidence;
	}
	public void setAssociation(Hashtable<String, Association> association) {
		this.association = association;
	}
	public void setMin_confidence(float min_confidence) {
		this.min_confidence = min_confidence;
	}
	public String[][] getDataset() {
		return dataset;
	}
	public void setDataset(String[][] dataset) {
		this.dataset = dataset;
	}
	public Hashtable <Integer,Hashtable<String, ArrayList<Integer>>> getL() {
		return L;
	}
	public double[] gen_intervall(int index,int nbSubranges){
		double[] attData=data.attributeToDoubleArray(index);
		double[] limitValues=new double[nbSubranges+1];
	   // System.out.println(data.attribute(index).name()+" *** is numeric");		
	    double max = Arrays.stream(attData).max().getAsDouble();
	    double min = Arrays.stream(attData).min().getAsDouble();
	    double range_width=(max-min)/nbSubranges;
	    double q=min;
	    for(int i=0;i<nbSubranges;i++){
	    	limitValues[i]=q;
	    	q+=range_width;
	    }
	    limitValues[nbSubranges]=max;  		
		return limitValues;
	}
	
	public ArrayList<Integer> gen_index_intervalle(int index, double lowerbound,double upperbound){
		ArrayList<Integer> idt_item=new ArrayList();
		double[] attData=data.attributeToDoubleArray(index);
		for(int i=0;i<attData.length;i++){
			if ((attData[i]>=lowerbound) && (attData[i]<upperbound)){
				idt_item.add(i);
			}
		}
		return idt_item;
	}

	public Hashtable<String, ArrayList<Integer>> eclat_gen_L1() {
		String[][] dataset=this.getDataset();
		Hashtable<String, ArrayList<Integer>> c1=new Hashtable<String, ArrayList<Integer>>();
		Hashtable<String, ArrayList<Integer>> L1=new Hashtable<String, ArrayList<Integer>>();
		ArrayList<Integer> idt_item;
		String item;
		int nbSubranges=5;
		for(int j=0;j<dataset[0].length;j++) {
			switch (j){
			case 0:
			case 3:
			case 4:
			case 7:
			case 9:
			case 11:{//System.out.println(data.attribute(j).name()+" *** is numeric");			
			double[] limitValues=gen_intervall(j,nbSubranges);
		    for(int i=0;i<nbSubranges;i++){
		    	c1.put((int)limitValues[i]+"-"+(int)limitValues[i+1]+"_"+j, gen_index_intervalle(j, limitValues[i], limitValues[i+1]));
		    }   
			};break;
			default: {//System.out.println(data.attribute(j).name()+" ----- is not numeric");
			          for(int i=0;i<dataset.length;i++) {
						item=dataset[i][j]+"_"+j;
						if(c1.get(item) == null) {
							idt_item=new ArrayList();
							idt_item.add(i);
							c1.put(item,idt_item);
						}else {
							idt_item=c1.get(item);
							if(idt_item.contains(i) == false) {
								idt_item.add(i);
								c1.put(item,idt_item);
							}				
						}
			          }
					};
			}
		}	
		//filter with respect to the support of the items:
		for(String key:c1.keySet()) {
			if(this.contrainte(c1.get(key))) L1.put(key,c1.get(key)); 		
		}
		
		// add the nb_itemset into the global item:
		this.setL(L1,1);		
		return L1;
	}
	
	//print nb_itemset key(combination/itemset)-> index of lines (where the itemset occurs)
	public void print_dict(Hashtable<String, ArrayList<Integer>> L ) {		
		for(String key: L.keySet()) {
			  System.out.print("\n \nl'Item ----      "+key+"  apparient aux interactions::");
			  ArrayList<Integer> a=L.get(key);
              for(int i=0;i<a.size();i++) {
            	  System.out.print("\t "+a.get(i));
              }
		  }		
	}
	
	//print list of integer:
	public void print_arraylist(ArrayList L) {
		for(int i=0;i<L.size();i++) {
			System.out.print("\t"+L.get(i));
		}		
		System.out.print("\n");		
	}
	
	//print the rules for specific condidate:
	public void print_association(String key) {
		Association asso=this.getAssociation().get(key);
		System.out.println("les regles pour le condidat ------------------- "+asso.getCondidate());
		for(int i=0;i<asso.getRules().size();i++) {
			System.out.println("\t\t "+asso.rules.get(i).getGauche()+" ==> "+asso.rules.get(i).getDroite().toString()+" :: confidence ----"+asso.rules.get(i).getConfidence());
		}
	}
	
	//print rules for each condidate:
	public String print_all_association() {	
	String str="";
	for(String key: this.getAssociation().keySet()) {	
		Association asso=this.getAssociation().get(key);
		str=str+"les regles pour le condidate ------------------------------ "+asso.getCondidate()+"\n";
		for(int i=0;i<asso.getRules().size();i++) {
			str=str+"\t\t "+asso.rules.get(i).getGauche()+" ==> "+asso.rules.get(i).getDroite().toString()+" :: confidence ----"+asso.rules.get(i).getConfidence()+"\n";
		 }		
	   }
	return(str);
	}
	
	//compute the intersection of 2 listes of indexes
	public ArrayList<Integer> intersection(ArrayList<Integer> l1, ArrayList<Integer> l2) { 
		ArrayList<Integer> result=new ArrayList();
		for(int i=0;i<l1.size();i++) {
			for(int j=0;j<l2.size();j++) {
				if(l1.get(i) == l2.get(j))
					result.add(l1.get(i));					
			}
		}	
		return result;
	}
	
	//verifier si deux items sont de la meme attribut
	public boolean Item_intersection(String s1,String s2) {
		String[] a=s1.split(",");
		String[] b,c;
		c=s2.split("_");	
		for(int i=0;i<a.length;i++) {
			    b=a[i].split("_");			    
				if(b[1].equals(c[1])) return true;
		}
	   return false;
	}
	
	//test if the frequency of itemset respect the minsupport constraint:
	public boolean contrainte(ArrayList<Integer> L) {
		int supp=this.getMin_support();
		if(L.size() >= supp) return true;
		else return false;		
	}
	
	
	public  Hashtable<String, ArrayList<Integer>> eclat_gen(Hashtable<String, ArrayList<Integer>> L1,Hashtable<String, ArrayList<Integer>> L, int k) {
	//	System.out.println("\n\n=============================================== "+(k+1) +" eme ITERATION ====================================================");
		Hashtable<String, ArrayList<Integer>> ck=new Hashtable<String, ArrayList<Integer>>();
        ArrayList<Integer> intersection=new ArrayList();
        Hashtable<String,Integer> close=new Hashtable(); // enregister les item deja trait� 0 pour dir ens vide de transaction  et 1 pour dir que il ya une interaction et 2 pour dir ne respecte pas les contrainte

		String[] liste_j;
        liste_j=new String[k];
        String new_key;
        
        
        //former table of keys
        ArrayList<String> tab_key=new ArrayList();
        for(String i: L.keySet()) {
        	tab_key.add(i);
        }
        
        //start:
		for(int counter_i=0;counter_i<tab_key.size();counter_i++) {
			String i=tab_key.get(counter_i);
			tab_key.remove(i); //supprimer item i pour eviter les repetition
			for(int counter_j=0;counter_j<tab_key.size();counter_j++) {
				String j=tab_key.get(counter_j);
				liste_j=j.split(",");	
			    	for(int m=0;m<k;m++) {	
				    	new_key=i+","+liste_j[m];
				    	if(Item_intersection(i,liste_j[m]) == false && close.get(new_key) == null) {
				    		//System.out.println("==========>>>>   "+new_key);
	 			    			intersection=this.intersection(L.get(i),L1.get(liste_j[m]));
				    			if(intersection.isEmpty() == false) {
				    				if(this.contrainte(intersection) == true) {
				    					ck.put(new_key,intersection);
				    					close.put(new_key,1);
				    					//affichage
					    			//	System.out.print("\t ----------------------  SUCESS ");
					    			//	this.print_arraylist(ck.get(new_key));
				    				}else {
				    					close.put(new_key,2);
				    					//System.out.println("\n ERROR \t "+new_key+" ne respecte pas la contrainte"); 					
				    				} 
				    					    				
				    			}else {
			    					close.put(new_key,0);
				    				//System.out.println("\n ERROR \t intersection vide pour element: "+new_key+" ::");
				    			}
				    			
				    		}	   
			    }
				
			}
			
		} 
	//	System.out.println("______________________________________________________ RESULTAT DE LE "+(k+1)+" eme iteration ___________________________________________________ ");
		//this.print_dict(ck);
		this.setL(ck,k+1);
		return ck;
		
	}
	
	 public static ArrayList<Map.Entry<String, Integer>> sortValue(Hashtable<String, Integer> t){
	       //Transfer as List and sort it
	       ArrayList<Map.Entry<String, Integer>> l = new ArrayList(t.entrySet());
	       Collections.sort(l, new Comparator<Map.Entry<String, Integer>>(){
	         public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
	            return o2.getValue().compareTo(o1.getValue());
	        }});
	       return(l);
	    }
	 
	public ArrayList<String> LtoStringFreqList(int itemSize,int condidate_number){
		ArrayList<String> lStr=new ArrayList();
		Hashtable<String,Integer> list=new Hashtable<String, Integer>();
		if(itemSize==0){//with respect to freq case:
			for(int key:this.L.keySet()){
			   for(String k: this.L.get(key).keySet()){
				   list.put(k, L.get(key).get(k).size());
			   }
			}				
		}
		else{//with respect to size of itemset case:
				   for(String k: this.L.get(itemSize).keySet()){
					   list.put(k, L.get(itemSize).get(k).size());
				   }							
		}
		ArrayList<Map.Entry<String, Integer>> l=sortValue(list);
		int i=0;
		for (Map.Entry<String, Integer> map : l)
		        {					      
		        if(i==condidate_number) break;
		        lStr.add(map.getKey());
		        i++;
		        }
		return lStr;
	}
	
	
	public void gen_association(String condidate) {
		double confidence =this.getMin_confidence();
		Association a =new Association(condidate,this.getL(),confidence);
		a.ASSOCIATION(1,this.d);
		this.setAssociation(condidate,a);		
	}
	
	public void gen_nb_associations(ArrayList<String> condidates){
		for(String str: condidates){
			gen_association(str);
		}
	}		
	public void save_xml(String filename,Hashtable<String, ArrayList<Integer>> L) throws FileNotFoundException {
		FileOutputStream fos = new FileOutputStream(filename);
		XMLEncoder e = new XMLEncoder(fos);
		e.writeObject(L);
		e.close();
	}	
	public void save_itemsets_struct(Hashtable<Integer,Hashtable<String, ArrayList<Integer>>> dict) {
		try {
			FileOutputStream f = new FileOutputStream(new File("itemsets.txt"));
			ObjectOutputStream o = new ObjectOutputStream(f);

			// Write objects to file
			o.writeObject(dict);
			o.close();
			f.close();
		} catch (FileNotFoundException e1) {
			System.out.println("File not found");
		} catch (IOException e2) {
			System.out.println("Error initializing stream");
		}
	}
	
	
	public Hashtable<Integer,Hashtable<String, ArrayList<Integer>>> open_itemsets_struct() {
		Hashtable<Integer,Hashtable<String, ArrayList<Integer>>> dict=null;
		try {					
		FileInputStream fi = new FileInputStream(new File("itemsets.txt"));
		ObjectInputStream oi = new ObjectInputStream(fi);
		// Read objects
		dict= (Hashtable<Integer,Hashtable<String, ArrayList<Integer>>>) oi.readObject();
		oi.close();
		fi.close();
	} catch (FileNotFoundException e1) {
		System.out.println("File not found");
	} catch (IOException e2) {
		System.out.println("Error initializing stream");
	} catch (ClassNotFoundException e3) {
		// TODO Auto-generated catch block
		
	}		
		return dict;
	}
		
	public void save_associations_struct(Hashtable<String, Association> dict) {
		try {
			FileOutputStream f = new FileOutputStream(new File("association.txt"));
			ObjectOutputStream o = new ObjectOutputStream(f);
			// Write objects to file
			o.writeObject(dict);
			o.close();
			f.close();
		} catch (FileNotFoundException e1) {
			System.out.println("File not found");
		} catch (IOException e2) {
			System.out.println("Error initializing stream");
		}
	}	
	
	public Hashtable<String, Association> open_associations_struct() {
		Hashtable<String, Association> dict=null;
		try {					
		FileInputStream fi = new FileInputStream(new File("association.txt"));
		ObjectInputStream oi = new ObjectInputStream(fi);
		// Read objects
		dict= (Hashtable<String, Association>) oi.readObject();
		oi.close();
		fi.close();		
	} catch (FileNotFoundException e1) {
		System.out.println("File not found");
	} catch (IOException e2) {
		System.out.println("Error initializing stream");
	} catch (ClassNotFoundException e3) {
		// TODO Auto-generated catch block		
	}		
		return dict;
	}
	
	public boolean condition_arret(int k) {
		if(k == this.max_set_size) return true;
		return false;
	}
	
   public void ECLAT(){	
		boolean condition_arret;
		Hashtable<String, ArrayList<Integer>> L1=new Hashtable();
		int k=1;		
		L1=eclat_gen_L1();
		if(this.condition_arret(1) == false) condition_arret=false;else condition_arret=true;
		Hashtable<String, ArrayList<Integer>> L_actuel;
		L_actuel=L1;		
		while(condition_arret == false){
			L_actuel=eclat_gen(L1,L_actuel,k);
			k++;
			condition_arret=this.condition_arret(k);
		}
		save_itemsets_struct(getL());
		gen_nb_associations(LtoStringFreqList(this.ass_cond,this.nb_condidates));	
	}
}
