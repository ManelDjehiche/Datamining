package application;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** JDK 7+. */
public final class SmallBinaryFiles {
  
  public static void main(String[] args) throws IOException {
    SmallBinaryFiles binary = new SmallBinaryFiles();
    byte[] bytes = binary.readSmallBinaryFile(FILE_NAME);
    log("Small - size of file read in:" + bytes.length);
    binary.writeSmallBinaryFile(bytes, OUTPUT_FILE_NAME);
  }

  final static String FILE_NAME = "Documents";
  final static String OUTPUT_FILE_NAME = "C:\\Temp\\cottage_output.jpg";
  
  byte[] readSmallBinaryFile(String fileName) throws IOException {
    Path path = Paths.get(fileName);
    return Files.readAllBytes(path);
  }
  
  void writeSmallBinaryFile(byte[] bytes, String fileName) throws IOException {
    Path path = Paths.get(fileName);
    Files.write(path, bytes); //creates, overwrites
  }
  
  private static void log(Object msg){
    System.out.println(String.valueOf(msg));
  }
} 