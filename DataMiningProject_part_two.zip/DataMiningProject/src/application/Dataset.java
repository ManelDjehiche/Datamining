package application;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Attribute;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;

public class Dataset {


    private int nbr_instance;
    private Instances dataset;
    private int nbr_attribut;
    private Attribute[] attribute;
    private String[][] dataset_table;
    private int[][] missing_values;



    public Dataset(Instances dataset) {
        this.dataset = dataset;
        setNbr_attribut(dataset.numAttributes());
        setNbr_instance(dataset.numInstances());
        setDataset_table(creation_table_dataset());
        setAttribute(creation_liste_attribute());
        setMissing_values(creation_missingvalue());
    }
    public Instances getDataset(){
        return this.dataset;
    }

    public void setDataset(Instances dataset) {
        this.dataset = dataset;
    }


    public int[][] getMissing_values() {
        return missing_values;
    }

    public void setMissing_values(int[][] missing_values) {
        this.missing_values = missing_values;
    }



    public int getNbr_instance() {
        return nbr_instance;
    }

    public void setNbr_instance(int nbr_instance) {
        this.nbr_instance = nbr_instance;
    }

    public int getNbr_attribut() {
        return nbr_attribut;
    }

    public void setNbr_attribut(int nbr_attribut) {
        this.nbr_attribut = nbr_attribut;
    }

    public Attribute[] getAttribute() {
        return attribute;
    }

    public void setAttribute(Attribute[] attribute) {
        this.attribute = attribute;
    }

    public String[][] getDataset_table() {
        return dataset_table;
    }

    public void setDataset_table(String[][] dataset) {
        this.dataset_table= dataset;
    }



    private Attribute[] creation_liste_attribute(){
        Attribute att[]=new Attribute[this.getNbr_attribut()];
        for(int i=0;i<this.getNbr_attribut();i++){
            att[i]=this.getDataset().attribute(i);
        }
        return att;
    }

    private String[][] creation_table_dataset(){
        String[][] dataset_table=new String[this.nbr_instance][this.getNbr_attribut()];
        for(int i=0;i<this.nbr_instance;i++){
            String[] part=new String[this.getNbr_attribut()];
                     part=(""+this.getDataset().instance(i)).split(",");
            for(int j=0;j<getNbr_attribut();j++){
                dataset_table[i][j]=part[j];
            }

            }
        return dataset_table;
    }

    private int[][]  creation_missingvalue() {
        String[][] dataset = this.getDataset_table();
        int[][] missing_value = new int[this.nbr_instance][this.getNbr_attribut()];
        for (int i = 0; i < this.nbr_instance; i++) {
            for (int j = 0; j < getNbr_attribut(); j++) {
                if (dataset[i][j] == "") missing_value[i][j] = 1; /* is missing */
                else missing_value[i][j] = 0; /* not missing */
            }
        }
        return missing_value;
    }

    public void print_dataset_table(){
        String[][] tab=this.getDataset_table();

        for (int i = 0; i < tab.length; i++) {
            System.out.println("___________________________________________________________________________________________________________");
            System.out.print("instance  "+ i +"|| ");

            for (int j = 0; j < tab[i].length; j++) {
                System.out.printf("%s \t", tab[i][j]);
                if (j < tab[i].length - 1) {
                    System.out.print("| ");
                }
            }
            System.out.println();
        }
    }

    public void print_missing_values(){
        int[][] tab=this.getMissing_values();

        for (int i = 0; i < tab.length; i++) {
            System.out.println("__________________________________________________________________________________________________________________");
            System.out.print("instance  "+ i +"|| ");
            for (int j = 0; j < tab[i].length; j++) {
                System.out.printf("%d \t", tab[i][j]);
                if (j < tab[i].length - 1) {
                    System.out.print("| ");
                }
            }
            System.out.println();
        }
    }


    /********************* PREPROCESSING **********************/
    private void Box_plot(Attribute a){

    }
    private double median(Attribute a){
        double median = 0;

        return median;
    }

    private double Mode(Attribute a){
        double mode=0;

        return mode;
    }

    private double mean(Attribute a){
        double mean=0;
        return mean;
    }

    private double[] value_of_attribute(Attribute a){
        double value[]=new double[this.nbr_instance];

        return value;
    }

    static double median(double[] values) {
        // sort array
        Arrays.sort(values);
        double median;
        // get count of scores
        int totalElements = values.length;
        // check if total number of scores is even
        if (totalElements % 2 == 0) {
            double sumOfMiddleElements = values[totalElements / 2] +
                    values[totalElements / 2 - 1];
            // calculate average of middle elements
            median = ((double) sumOfMiddleElements) / 2;
        } else {
            // get the middle element
            median = (double) values[values.length / 2];
        }
        return median;
    }


    private  double moyenne_tableau_guava (double array[]) {
        float mean;
        int sum, i;
        int n = array.length;
        sum = 0;
        for(i = 0; i < n; i++) {
            sum+=array[i];
        }

        return sum/(double)n;
    }

    public  double Mode(double[] a)
    {
        int index = 0  ;
        int soFar = 1 ;
        int count = 1 ;
        for(int k =1;   k < a.length; k++){
            if (a[k-1] == a[k]){
                count++ ; }
            if(count > soFar)
            {
                soFar = count ;
                index = k ;
            }
            else {
                count = 1 ;
            }
        }
        return a[index] ;
    }

}
