package application;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;

public class Association {
	private String  condidate; //father
	private ArrayList<String> condidate_liste=new ArrayList<String>();
	private Hashtable<Integer,Hashtable<String, ArrayList<Integer>>> L=new Hashtable<Integer,Hashtable<String, ArrayList<Integer>>>();
    ArrayList<Rule> rules=new ArrayList<Rule>();
    int ordre;
    
    double min_confidence;
    
	public String getCondidate() {
		return condidate;
	}

	public void setCondidate(String condidate) {
		this.condidate = condidate;
	}

	public ArrayList<String> getCondidate_liste() {
		return condidate_liste;
	}

	public void setCondidate_liste(ArrayList<String> condidate_liste) {
		this.condidate_liste = condidate_liste;
	}

	public Hashtable<Integer, Hashtable<String, ArrayList<Integer>>> getL() {
		return L;
	}

	public void setL(Hashtable<Integer, Hashtable<String, ArrayList<Integer>>> l) {
		L = l;
	}


	public ArrayList<Rule> getRules() {
		return rules;
	}


	public void setRules(Rule rule) {
		this.rules.add(rule);
	}


	public int getOrdre() {
		return ordre;
	}


	public void setOrdre(int ordre) {
		this.ordre = ordre;
	}

	public double getMin_confidence() {
		return min_confidence;
	}


	public void setMin_confidence(int min_confidence) {
		this.min_confidence = min_confidence;
	}


	public void setRules(ArrayList<Rule> rules) {
		this.rules = rules;
	}


	public Association(String condidate, Hashtable<Integer, Hashtable<String, ArrayList<Integer>>> l,double confidence) {
		super();
		this.condidate = condidate;
		this.L = l;
		this.min_confidence=confidence;			
		// generer le condidate sous forme d'une liste pour simplifier la suppression d'un element
		String[] cond=condidate.split(",");
		for(int i=0;i<cond.length;i++) {
			this.condidate_liste.add(cond[i]);
		}		
		this.ordre=condidate_liste.size();	
	}


	public ArrayList<String> intersection(ArrayList<String> r1,ArrayList<String> l2){
		ArrayList<String> result=new ArrayList();
		for(int i=0;i<r1.size();i++) {
			for(int j=0;j<l2.size();j++) {
				if(r1.get(i) == l2.get(j))
					result.add(r1.get(i));
					
			}
	}
		return result;
	}
	
	
	public 	ArrayList<String> remove(ArrayList<String> list, String element) {
		ArrayList<String> result=new ArrayList<String>();
		for(int i=0;i<list.size();i++) {
			if(list.get(i) != element) result.add(list.get(i));
		}
				
		return result;
	}
	

	//verifier si deux item sont de la mem attribut
	public boolean Item_droite(String s1,String s2) {

		String[] a=s1.split(",");
		String[] b,c;
		c=s2.split("_");
		
		for(int i=0;i<a.length;i++) {
			    b=a[i].split("_");			    
				if(b[1].equals(c[1])) return true;
		}
	   return false;
	}
	
	
	public Hashtable<String, ArrayList<String>>  gen_1_rules(int algo_index) {

			Hashtable<String, ArrayList<String>> r1=new Hashtable<String, ArrayList<String>>();
			ArrayList<Integer> idt_item;
			ArrayList<String> condidate= this.getCondidate_liste();
			ArrayList<String> droite;
			String gauche;
			int supportg;
			int support_father;
			System.out.println("\n\n------------------------------ GENERATION DE R1 pour "+this.getCondidate());
			
			// former les regle de la forme 1-item => {}
			for(int i=0;i<this.ordre;i++) {
				gauche=condidate.get(i);
	            droite=this.remove(condidate,gauche);
	            
	            if(algo_index==1){//eclat:
	            supportg=this.getL().get(1).get(gauche).size();
	            support_father=this.getL().get(ordre).get(this.getCondidate()).size();
			    }
	            
	            else{//apriori:
	            supportg=this.getL().get(1).get(gauche).get(0);
	  	        support_father=this.getL().get(ordre).get(this.getCondidate()).get(0);
	            }
	            
	            r1.put(gauche,droite);
	            // creer la regle
				Rule r= new  Rule(gauche,droite,supportg,support_father);
				//System.out.println("\n\t -------  | "+r.getGauche()+" => "+r.getDroite().toString()+" | \tCONFIFENCE   "+r.getConfidence());

				this.setRules(r);
				
			}
			
			return r1;
			
	}
	
	public void print_dict(Hashtable<String, ArrayList<String>> L ) {
		
		for(String key: L.keySet()) {
			  System.out.print("\n \t  rule ----      "+key+"  apparient aux interactions::");
			  ArrayList<String> a=L.get(key);
              for(int i=0;i<a.size();i++) {
            	  System.out.print("\t "+a.get(i));
              }
		  }		
	}
	
	public void print_arraylist(ArrayList L) {

		for(int i=0;i<L.size();i++) {
			System.out.print("\t"+L.get(i));
		}
		
		System.out.print("\n");
		
	}
	
	public boolean contrainte(Rule L) {

		double conf=this.getMin_confidence();
		if(L.getConfidence() >= conf) return true;
		else return false;
		
	}
	
	public ArrayList<Integer> intersection_interger_arraylist(ArrayList<Integer> l1, ArrayList<Integer> l2) { 
		ArrayList<Integer> result=new ArrayList();
		for(int i=0;i<l1.size();i++) {
			for(int j=0;j<l2.size();j++) {
				if(l1.get(i) == l2.get(j))
					result.add(l1.get(i));
					
			}
		}
	
		return result;
	}
	

	public boolean condition_arret(Hashtable<String, ArrayList<String>> ck) {

		if(ck.keySet().size() == 0) return true;
		return false;
	}

	

	
	//compute the intersection of 2 listes of indexes
		public ArrayList<Integer> intersection_int(ArrayList<Integer> l1, ArrayList<Integer> l2) { 
			ArrayList<Integer> result=new ArrayList();
			for(int i=0;i<l1.size();i++) {
				for(int j=0;j<l2.size();j++) {
					if(l1.get(i) == l2.get(j))
						result.add(l1.get(i));					
				}
			}	
			return result;
		}
	
		
		public ArrayList<Integer> occur_lines_index(String str,String[][] dataset){
			String[] b=str.split("_");
			String val=b[0];
			int index=Integer.valueOf(b[1]).intValue();
			ArrayList<Integer>idt_item=new ArrayList();
			String[] bordure=b[0].split("-");
			double min= new Double(bordure[0]);
			double max= new Double(bordure[1]);
			  for(int i=0;i<dataset.length;i++){
			  
			  if(new Double(dataset[i][index]) >= min && new Double(dataset[i][index]) <= max){
				  if(idt_item.contains(i) == false) idt_item.add(i); 
				 
			  } 
			  
			  }
			  
		 
			return idt_item;
		}
		
		
		//compute the intersection of 2 listes of indexes
		public ArrayList<Integer> intersection_string_arraylist(ArrayList<Integer> l1, ArrayList<Integer> l2) { 
			ArrayList<Integer> result=new ArrayList();
			for(int i=0;i<l1.size();i++) {
				for(int j=0;j<l2.size();j++) {
					if(l1.get(i) == l2.get(j))
						result.add(l1.get(i));					
				}
			}	
			return result;
		}
		
		//compute the freq sets:
		public int  intersection_freq(String s1,String[][] datatset) {
			//System.out.println("--------------------- INTERSECTION ENTRE  "+s1+"  AND  "+s2+" ------------------");
			String[] a=s1.split(",");
			ArrayList<Integer> l=occur_lines_index(a[0],datatset);	 //liste d'instance ou les valeur de set exist			
			//System.out.print("\n"+s2+"\t  : ");print_arraylist(l);	
			//System.out.print("\n"+s1+"\t  : ");
			for(String i:a) {
				ArrayList<Integer> argList=occur_lines_index(i,datatset);
				//System.out.print("\n\t\t"+i+" : ");print_arraylist(argList);
				l=intersection_string_arraylist(l,argList);
				if(l.size()==0) break;
			}
			
			//System.out.println("\n intersection ===> "+l.toString());
			return l.size();
		}
			
	public int get_gauche_support(String gauche,int algo_index, Dataset d,String[][] datatset) {
		int support=0;
		if(algo_index==1){//eclat:
		String[] tab= gauche.split(",");
		ArrayList<Integer> support_interval,first;		
		int i=0;
		first=this.getL().get(1).get(tab[i]);
		
		support_interval=intersection_interger_arraylist(first,first); // pour obtenir nouveau objet et ne pas ecraser celui de Lk
		for(int j=i+1;j<tab.length;j++) {
				support_interval=this.intersection_interger_arraylist(support_interval,this.getL().get(1).get(tab[j]));
			}	
	    support=support_interval.size();
		}
		else{//apriori:
			support=intersection_freq(gauche,datatset);
		}
		return support;		
	}

	boolean existe(Hashtable<String,Integer> close,String a) {

		String[] b = a.split(",");
	    ArrayList<Integer> tab=new ArrayList();

		int cpt=0;
			for(String k: close.keySet()) {
				String[] c=k.split(",");
				
				for(int i=0;i<b.length;i++) {
				if(Arrays.asList(c).contains(b[i]) == false) tab.add(0);
				if(Arrays.asList(c).contains(b[i]) == true) tab.add(1);
				}
				
				for(int m=0;m<b.length;m++) {
					if(tab.get(m) == 1) cpt++;
				}
				
				if(cpt == b.length) return true;
				else {
				    tab=new ArrayList();
					cpt=0;
				}
				
			}
			
		return false;
		}
		
	
public  Hashtable<String, ArrayList<String>> rules_gen(Hashtable<String, ArrayList<String>> r1,Hashtable<String, ArrayList<String>> r, int k,int algo_index,Dataset d,String[][] datatset) {
		int a=k+1;
	    System.out.println("\n\n------------------------------ GENERATION DE R"+a+" pour  "+this.getCondidate()+" --------------------- \n\n");
		Hashtable<String, ArrayList<String>> rk=new Hashtable<String, ArrayList<String>>();
        Hashtable<String,Integer> close=new Hashtable(); 
        ArrayList<String> droite=new ArrayList<String>();
		ArrayList<String> condidate= this.getCondidate_liste();
        String gauche;
        int supportg;
		int support_father;
        
        
		String[] liste_j;
        liste_j=new String[k];
        

        //former table of keys
            String[] tab_key=new String[r.keySet().size()];
            int b=0;
            for(String i: r.keySet()) {
            	tab_key[b]=i;
            	b++;
            }

            //start:
    		for(int counter_i=0;counter_i<tab_key.length;counter_i++) {
    			String i=tab_key[counter_i];
    	         //supprimer item i pour eviter les repetition
    			for(int counter_j=counter_i+1;counter_j<tab_key.length;counter_j++) {
    				 
    				String j=tab_key[counter_j];
					liste_j=j.split(",");	
				    	for(int m=0;m<k;m++) {	
					    	gauche=i+","+liste_j[m];
					    	if(Item_droite(i,liste_j[m]) == false && existe(close,gauche)==false) {
					    	

	 			    			  droite=this.intersection(r.get(i),r1.get(liste_j[m]));						
								  if(droite.isEmpty() == false) { 
							
                      
								  rk.put(gauche,droite); close.put(gauche,1);
								  
								  //crrer rule 								  
								  supportg=this.get_gauche_support(gauche,algo_index,d,datatset);
								  Rule rule=null;
								  
								  if(algo_index==1){//eclat:
								  support_father=this.getL().get(this.getOrdre()).get(this.getCondidate()).size();
								  rule =new Rule(gauche,droite,supportg,support_father);
								  }
								  else{//apriori:
									  support_father=this.getL().get(this.getOrdre()).get(this.getCondidate()).get(0);											  
									  rule =new Rule(gauche,droite,supportg,support_father);
								  }
								  this.setRules(rule);
								  
								  //affichage
								  // System.out.println("\n\t HERE -------  | "+rule.getGauche()+" => "+rule.getDroite().toString()+" | \tCONFIFENCE: gauche:: "+supportg+" pere:: "+support_father);

								  
								  }else { close.put(gauche,0);
								  
								  }
								  
								  
						 
					    		}	   
				    }
				
			}
			
			
		} 
		//System.out.println("_________________________________________________________________________________________________________________________ ");
		
		return rk;
		
	}
	

	public void ASSOCIATION(int algo_index,Dataset d,String[][] dataset){
		
		//0: apriori 1:eclat
		boolean condition_arret;
		Hashtable<String, ArrayList<String>> r1=new Hashtable();
		int k=1;
		if(algo_index==1){//eclat:
		r1=gen_1_rules(algo_index);
		// Generer tout autre ensemble de taille k
		if(this.condition_arret(r1) == false) condition_arret=false;else condition_arret=true;
		Hashtable<String, ArrayList<String>> L_actuel;
		L_actuel=r1;		
		while(condition_arret == false){
			L_actuel=rules_gen(r1,L_actuel,k,algo_index,d,dataset);
			k++;
			condition_arret=this.condition_arret(L_actuel);
		}
		}
		
		else{//apriori:
			r1=gen_1_rules(algo_index);
			// Generer tout autre ensemble de taille k
			if(this.condition_arret(r1) == false) condition_arret=false;else condition_arret=true;
			Hashtable<String, ArrayList<String>> L_actuel;
			L_actuel=r1;		
			while(condition_arret == false){
				L_actuel=rules_gen(r1,L_actuel,k,algo_index,d,dataset);
				k++;
				condition_arret=this.condition_arret(L_actuel);
			}
		}
		
		// supprimer les regles qui ne depasse pas la seuil de confidence
		ArrayList<Rule> rule_filtred=new ArrayList<Rule>();
		for(int i=0;i<this.getRules().size();i++) {
			if(this.contrainte(this.getRules().get(i)) == true) {
				rule_filtred.add(this.getRules().get(i));
				
			}
		}
		
	    this.setRules2(rule_filtred);
		
	}	
	public void setRules2(ArrayList<Rule> R) {
		this.rules=R;
	}
}
