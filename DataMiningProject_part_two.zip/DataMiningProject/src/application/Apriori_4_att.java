package application;

import java.beans.XMLEncoder;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import weka.core.Instances;

public class Apriori_4_att {
	private int min_support;
	private double min_confidence;
	private String[][] dataset;
	private Hashtable<Integer,Hashtable<String, ArrayList<Integer>>> L=new Hashtable<Integer,Hashtable<String, ArrayList<Integer>>>(); //dic.put(S,o);  //o=dic.get(S); return object   //Integer I=(Integer)dic.get("deux");
	private Hashtable<String,Association> association=new  Hashtable<String,Association>(); // key est le condidate frequent dans dataset, et lobject association coontient touts les regles d'association de ce condidat
    private Instances data;
	private Dataset d;
	public Apriori_4_att(int min_support, double min_confidence,Instances data) {
		super();
		this.min_support = min_support;
		this.min_confidence = min_confidence;
		this.data=data;
		this.d=new Dataset(data);
		String[][]table =d.getDataset_table();
		
		this.dataset=new String[table.length][table[0].length];
		for(int i=0;i<table.length;i++) {
			for(int j=0;j<table[i].length;j++) {
				this.dataset[i][j]=table[i][j];
			}
		}		
	   }
	
	public static int frequency(double[] attData, double min , double max){
		int freq=0;
		int i=0,length=attData.length;
		Arrays.sort(attData);
		while((i<length)&&(attData[i]<min)) i++;
		if(i<length){
			while((i<length)&&(attData[i]<=max)) {
				i++;
				freq++;
			}
		}
		return freq;
	}
	
	public double[] gen_intervall(int index,int nbSubranges){
		double[] attData=data.attributeToDoubleArray(index);
		double[] limitValues=new double[nbSubranges+1];
	   // System.out.println(data.attribute(index).name()+" *** is numeric");		
	    double max = Arrays.stream(attData).max().getAsDouble();
	    double min = Arrays.stream(attData).min().getAsDouble();
	    double range_width=(max-min)/nbSubranges;
	    double q=min;
	    for(int i=0;i<nbSubranges;i++){
	    	limitValues[i]=q;
	    	q+=range_width;
	    }
	    limitValues[nbSubranges]=max;  		
		return limitValues;
	}
	
	public ArrayList<Integer> gen_freq_intervalle(int index, double lowerbound,double upperbound){
		ArrayList<Integer> idt_item=new ArrayList();
		double[] attData=data.attributeToDoubleArray(index);
        idt_item.add(frequency(attData,lowerbound,upperbound));
		return idt_item;
	}
	
	public Hashtable<String, ArrayList<Integer>> apriori_gen_L1() {
		String[][] dataset=this.getDataset();
		Hashtable<String, ArrayList<Integer>> c1=new Hashtable<String, ArrayList<Integer>>();
		Hashtable<String, ArrayList<Integer>> L1=new Hashtable<String, ArrayList<Integer>>();
		ArrayList<Integer> idt_item;
		int nbSubranges=5;
			
		int[] index_4_att={0,3,4,7};

		for(int j=0;j<index_4_att.length;j++){
			double[] limitValues=gen_intervall(index_4_att[j],nbSubranges);
		    for(int i=0;i<nbSubranges;i++){
		    	c1.put((int)limitValues[i]+"-"+(int)limitValues[i+1]+"_"+index_4_att[j], gen_freq_intervalle(index_4_att[j], limitValues[i], limitValues[i+1]));
		    }   				       
		}	
		
		//filter with respect to the support of the items:
		for(String key:c1.keySet()) {
			if(this.contrainte(c1.get(key).get(0))) L1.put(key,c1.get(key)); 		
		}		
		// add the nb_itemset into the global item:
		this.setL(L1,1);		
		return L1;
	}
	
	//----------
	public ArrayList<Integer> occur_lines_index(String str){
		String[] b=str.split("_");
		String val=b[0];
		int index=Integer.valueOf(b[1]).intValue();
		ArrayList<Integer>idt_item=new ArrayList();
		String[] bordure=b[0].split("-");
		double min= new Double(bordure[0]);
		double max= new Double(bordure[1]);
		  for(int i=0;i<dataset.length;i++){
		  
		  if(new Double(this.dataset[i][index]) >= min && new Double(this.dataset[i][index]) <= max){
			  if(idt_item.contains(i) == false) idt_item.add(i); 
			 
		  } 
		  
		  }
		  
		  print_arraylist(idt_item);
	 
		return idt_item;
	}
	
	//compute the intersection of 2 listes of indexes
	public ArrayList<Integer> intersection(ArrayList<Integer> l1, ArrayList<Integer> l2) { 
		ArrayList<Integer> result=new ArrayList();
		for(int i=0;i<l1.size();i++) {
			for(int j=0;j<l2.size();j++) {
				if(l1.get(i) == l2.get(j))
					result.add(l1.get(i));					
			}
		}	
		return result;
	}
	//compute the freq of intersection of 2 sets:
		public int  intersection_freq(String s1, String s2) {
			//System.out.println("--------------------- INTERSECTION ENTRE  "+s1+"  AND  "+s2+" ------------------");
			String[] a=s1.split(",");
			ArrayList<Integer> l=occur_lines_index(s2);	 //liste d'instance ou les valeur de set exist			
			//System.out.print("\n"+s2+"\t  : ");print_arraylist(l);	
			//System.out.print("\n"+s1+"\t  : ");
			for(String i:a) {
				ArrayList<Integer> argList=occur_lines_index(i);
				//System.out.print("\n\t\t"+i+" : ");print_arraylist(argList);
				l=intersection(l,argList);
				if(l.size()==0) break;
			}
			
			//System.out.println("\n intersection ===> "+l.toString());
			return l.size();
		}
	//****************************
		
		boolean existe(Hashtable<String,Integer> close,String a) {

			String[] b = a.split(",");
		    ArrayList<Integer> tab=new ArrayList();

			int cpt=0;
				for(String k: close.keySet()) {
					String[] c=k.split(",");
					
					for(int i=0;i<b.length;i++) {
					if(Arrays.asList(c).contains(b[i]) == false) tab.add(0);
					if(Arrays.asList(c).contains(b[i]) == true) tab.add(1);
					}
					
					for(int m=0;m<b.length;m++) {
						if(tab.get(m) == 1) cpt++;
					}
					
					if(cpt == b.length) return true;
					else {
					    tab=new ArrayList();
						cpt=0;
					}
					
				}
				
			return false;
			}
		
	public  Hashtable<String, ArrayList<Integer>> apriori_gen(Hashtable<String, ArrayList<Integer>> L1,Hashtable<String, ArrayList<Integer>> L, int k) {
			Hashtable<String, ArrayList<Integer>> ck=new Hashtable<String, ArrayList<Integer>>();
	        Hashtable<String,Integer> close=new Hashtable(); // enregister les item deja trait� 0 pour dir ens vide de 
	        String[] liste_j;                                //transaction  et 1 pour dir que il ya une interaction et 2 pour dir ne respecte pas les contrainte			
	        liste_j=new String[k];
	        String new_key;
	        ArrayList<String> tab_key=new ArrayList();
	        for(String i: L.keySet()) {
	        	tab_key.add(i);
	        }
			for(int counter_i=0;counter_i<tab_key.size();counter_i++) {		
				String i=tab_key.get(counter_i);
				tab_key.remove(i); 
				for(int counter_j=0;counter_j<tab_key.size();counter_j++) {
					String j=tab_key.get(counter_j);
					liste_j=j.split(",");	
				    	for(int m=0;m<k;m++) {	
				    		
					    	new_key=i+","+liste_j[m];
					    	if(Item_intersection(i,liste_j[m]) == false && existe(close,new_key) == false) {
					    		
		 			    			int intersection= intersection_freq(i,liste_j[m]);//intersecet methode ret freq 0|>0
					    			if(intersection>0) {//if intersect>0		
					    				if(this.contrainte(intersection) == true) {// contrainte(freq)			
					    			        ArrayList<Integer> inters=new ArrayList();
					    			        inters.add(intersection);
					    					ck.put(new_key,inters);					    					
					    					close.put(new_key,1);
					    				}else {
					    					close.put(new_key,2);
					    				} 
					    					    				
					    			}else {//intersect==0
				    					close.put(new_key,0);					    			}					    			
					    		}	   
				    }					
				}				
			} 
			this.setL(ck,k+1);
			return ck;
			
		}
	//*************************
	
		
		//verifier si deux items sont de la meme attribut
		public boolean Item_intersection(String s1,String s2) {
			String[] a=s1.split(",");
			String[] b,c;
			c=s2.split("_");	
			for(int i=0;i<a.length;i++) {
				    b=a[i].split("_");			    
					if(b[1].equals(c[1])) return true;
			}
		   return false;
		}
				
		public boolean condition_arret(Hashtable<String, ArrayList<Integer>> L) {
			if(L.size() == 0) return true;
			return false;
		}	
		
	public void Apriori(){
		boolean condition_arret;
		Hashtable<String, ArrayList<Integer>> L1=new Hashtable();
		int k=1;		
		L1=apriori_gen_L1();
		if(this.condition_arret(L1) == false) condition_arret=false;else condition_arret=true;
		Hashtable<String, ArrayList<Integer>> L_actuel;
		L_actuel=L1;		
		while(condition_arret == false){
			L_actuel=apriori_gen(L1,L_actuel,k);
			k++;
			condition_arret=this.condition_arret(L_actuel);
		}
		save_itemsets_struct(getL());
		gen_nb_associations(LtoStringFreqList());
	}
	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		 Instances data = new Instances(new BufferedReader(new FileReader("C:\\Users\\user\\Desktop\\M2 SII USTHB\\data mining\\datasets-UCI\\UCI\\heart-statlog.arff")));
//Apriori(int min_support, double min_confidence,int max_set_size,int nb_condidates,int ass_cond,Instances data)
		 Apriori_4_att apriori=new Apriori_4_att(2,90,data);
		 apriori.Apriori();
		
		 apriori.print_all_association();
		 
		 
		
		  System.out.println("_______________________________________________________")
		  ;
		  
		  for(int x:apriori.getL().keySet()) {
		  System.out.println(x+" ------------ "+apriori.getL().get(x).size()); }
		 
		  
		  apriori.print_dict(apriori.getL().get(2));
		 
		/*
		 * Association a=apriori.getAssociation().get("136-157_3,0-1_1,3-4_2,38-48_0");
		 * ArrayList<Rule> r=a.getRules(); for(int k=0;k<r.size();k++) { Rule
		 * rule=r.get(k);
		 * System.out.println(" test =======================================");
		 * System.out.println("\n\t HERE -------  | "+rule.getGauche()+" => "+rule.
		 * getDroite().toString()+" | \tCONFIFENCE: "+rule.getConfidence()+" gauche:: "
		 * +rule.getGauche()+" pere:: "+rule.getDroite());
		 * 
		 * }
		 */


		/*
		 * CONDIDATE : 136-157_3,0-1_1,3-4_2,38-48_0
		 * 
		 * | 38-48_0,136-157_3 ==> [0-1_1, 3-4_2] | confidence : 75.0 |
		 * 38-48_0,136-157_3,0-1_1 ==> [3-4_2] | confidence : 75.0 |
		 * 38-48_0,136-157_3,3-4_2 ==> [0-1_1] | confidence : 100.0 |
		 * 38-48_0,0-1_1,136-157_3 ==> [3-4_2] | confidence : 75.0 |
		 * 3-4_2,136-157_3,38-48_0 ==> [0-1_1] | confidence : 100.0 |
		 * 3-4_2,38-48_0,136-157_3 ==> [0-1_1] | confidence : 100.0
		 */

		 
		 }
		  
		 
		 
	
	
	//generate getters & setters:
		public Hashtable<String, Association> getAssociation() {return association;}
		public void setAssociation(String key,Association association) {this.association.put(key,association);}
		public void setL(Hashtable<String, ArrayList<Integer>> l,Integer key) {L.put(key,l);}
		public int getMin_support() {return min_support;}
		public void setMin_support(int min_support) {this.min_support = min_support;}
		public double getMin_confidence() {return min_confidence;}
		public void setMin_confidence(double min_confidence) {this.min_confidence = min_confidence;}
	    public void setAssociation(Hashtable<String, Association> association) {this.association = association;}
		public void setMin_confidence(float min_confidence) {this.min_confidence = min_confidence;}
		public String[][] getDataset() {return dataset;}
		public void setDataset(String[][] dataset) {this.dataset = dataset;}
		public Hashtable <Integer,Hashtable<String, ArrayList<Integer>>> getL() {return L;}
	
		public static ArrayList<Map.Entry<String, Integer>> sortValue(Hashtable<String, Integer> t){
		       //Transfer as List and sort it
		       ArrayList<Map.Entry<String, Integer>> l = new ArrayList(t.entrySet());
		       Collections.sort(l, new Comparator<Map.Entry<String, Integer>>(){
		         public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
		            return o2.getValue().compareTo(o1.getValue());
		        }});
		       return(l);
		    }
		 
		public ArrayList<String> LtoStringFreqList(){
			ArrayList<String> lStr=new ArrayList();
			Hashtable<String,Integer> list=new Hashtable<String, Integer>();
				for(int key:this.L.keySet()){
				   if(key != 1) {
				   for(String k: this.L.get(key).keySet()){
					   list.put(k, L.get(key).get(k).get(0));
				   }
				   }
				 
				}							
			ArrayList<Map.Entry<String, Integer>> l=sortValue(list);
			for (Map.Entry<String, Integer> map : l)
			        {					      
			        lStr.add(map.getKey());
			        }
			return lStr;
		}
		
		
		public void gen_association(String condidate) {
			double confidence =this.getMin_confidence();
			Association a =new Association(condidate,this.getL(),confidence);
			a.ASSOCIATION(0,this.d,this.dataset);
			this.setAssociation(condidate,a);		
		}
		
		public void gen_nb_associations(ArrayList<String> condidates){
			for(String str: condidates){
				gen_association(str);
			}
		}		
		
		public boolean contrainte(int freq) {
			int supp=this.getMin_support();
			if(freq >= supp) return true;
			else return false;		
		}
		
	    	//print nb_itemset key(combination/itemset)-> index of lines (where the itemset occurs)
			public void print_dict(Hashtable<String, ArrayList<Integer>> L ) {		
				for(String key: L.keySet()) {
					  System.out.print("\n \nl'Item ---->  "+key+"  Frequence::");
					  ArrayList<Integer> a=L.get(key);
		              for(int i=0;i<a.size();i++) {
		            	  System.out.print("\t "+a.get(i));
		              }
				  }		
			}
			
			//print list of integer:
			public void print_arraylist(ArrayList L) {
				for(int i=0;i<L.size();i++) {
					System.out.print("\t"+L.get(i));
				}		
				System.out.print("\n");		
			}
			
			//print the rules for specific condidate:
			public void print_association(String key) {
				Association asso=this.getAssociation().get(key);
				//System.out.println("les regles pour le condidat ------------------- "+asso.getCondidate());
				for(int i=0;i<asso.getRules().size();i++) {
					//System.out.println("\t\t "+asso.rules.get(i).getGauche()+" ==> "+asso.rules.get(i).getDroite().toString()+" :: confidence ----"+asso.rules.get(i).getConfidence());
				}
			}
			
			//print rules for each condidate:
			public String print_all_association() {	
			String str="";
			String reg="";
			for(String key: this.getAssociation().keySet()) {
				str="";
				reg="";
				Association asso=this.getAssociation().get(key);
				if(asso.getRules().size() != 0) {
					str=str+"\n\t CONDIDATE : "+key+" _____________________________________________________________________________";
				for(int i=0;i<asso.getRules().size();i++) {
					reg=reg+"\t|\t "+asso.rules.get(i).getGauche()+" ==> "+asso.rules.get(i).getDroite().toString()+" | confidence : \t"+asso.rules.get(i).getConfidence()+"\n";
				 }
				str=str+"\n\n"+reg;
				System.out.println(str);
				}
				
				
			   }
			return(str);
			}
			
			//file manipulation:
			public void save_xml(String filename,Hashtable<String, ArrayList<Integer>> L) throws FileNotFoundException {
				FileOutputStream fos = new FileOutputStream(filename);
				XMLEncoder e = new XMLEncoder(fos);
				e.writeObject(L);
				e.close();
			}	
			public void save_itemsets_struct(Hashtable<Integer,Hashtable<String, ArrayList<Integer>>> dict) {
				try {
					FileOutputStream f = new FileOutputStream(new File("itemsets.txt"));
					ObjectOutputStream o = new ObjectOutputStream(f);

					// Write objects to file
					o.writeObject(dict);
					o.close();
					f.close();
				} catch (FileNotFoundException e1) {
					System.out.println("File not found");
				} catch (IOException e2) {
					System.out.println("Error initializing stream");
				}
			}
			
			
			public Hashtable<Integer,Hashtable<String, ArrayList<Integer>>> open_itemsets_struct() {
				Hashtable<Integer,Hashtable<String, ArrayList<Integer>>> dict=null;
				try {					
				FileInputStream fi = new FileInputStream(new File("itemsets.txt"));
				ObjectInputStream oi = new ObjectInputStream(fi);
				// Read objects
				dict= (Hashtable<Integer,Hashtable<String, ArrayList<Integer>>>) oi.readObject();
				oi.close();
				fi.close();
			} catch (FileNotFoundException e1) {
				System.out.println("File not found");
			} catch (IOException e2) {
				System.out.println("Error initializing stream");
			} catch (ClassNotFoundException e3) {
				// TODO Auto-generated catch block
				
			}		
				return dict;
			}
				
			public void save_associations_struct(Hashtable<String, Association> dict) {
				try {
					FileOutputStream f = new FileOutputStream(new File("association.txt"));
					ObjectOutputStream o = new ObjectOutputStream(f);
					// Write objects to file
					o.writeObject(dict);
					o.close();
					f.close();
				} catch (FileNotFoundException e1) {
					System.out.println("File not found");
				} catch (IOException e2) {
					System.out.println("Error initializing stream");
				}
			}	
			
			public Hashtable<String, Association> open_associations_struct() {
				Hashtable<String, Association> dict=null;
				try {					
				FileInputStream fi = new FileInputStream(new File("association.txt"));
				ObjectInputStream oi = new ObjectInputStream(fi);
				// Read objects
				dict= (Hashtable<String, Association>) oi.readObject();
				oi.close();
				fi.close();		
			} catch (FileNotFoundException e1) {
				System.out.println("File not found");
			} catch (IOException e2) {
				System.out.println("Error initializing stream");
			} catch (ClassNotFoundException e3) {
				// TODO Auto-generated catch block		
			}		
				return dict;
			}
}
