package application;

import weka.core.Attribute;

public class Statistics {
    String statName;
    double statValue;
	public Statistics(String statName, double statValue) {
		super();
		this.statName = statName;
		this.statValue = statValue;
	}
	public String getStatName() {
		return statName;
	}
	public void setStatName(String statName) {
		this.statName = statName;
	}
	public double getStatValue() {
		return statValue;
	}
	public void setStatValue(double statValue) {
		this.statValue = statValue;
	}
    
}
