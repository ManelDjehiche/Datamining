package application;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import weka.core.Instances;

public class test {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		 Hashtable<String, ArrayList<Integer>>L1=new Hashtable<String, ArrayList<Integer>>(); //dic.put(S,o);  //o=dic.get(S); return object   //Integer I=(Integer)dic.get("deux");
		 Hashtable<String, ArrayList<Integer>> L2=new Hashtable<String, ArrayList<Integer>>(); //dic.put(S,o);  //o=dic.get(S); return object   //Integer I=(Integer)dic.get("deux");
		 Instances data = new Instances(new BufferedReader(new FileReader("C:/Users/Lenovo/Desktop/M2-SII-S3 (2019-20)/Data Mining/Data Mining Projet 19-20/HEART_Stat.txt")));

		  Eclat eclat= new Eclat(30,10,2,3,2,data);
          eclat.ECLAT();
          L1=eclat.getL().get(2);
          
		  System.out.println("--------------------------------- 	Eclat  --------------------------------");
          System.out.println("--"+L1.get("213-301_4,0-1_9").size()+"--");
		 eclat.print_dict(L1);   
        //System.out.println(eclat.print_all_association());
          System.out.println("--------------------------------- 	APRIORI --------------------------------");
          Apriori apriori=new Apriori(30,10,2,3,2,data);
		     apriori.Apriori();
		     L2=apriori.getL().get(1);
		  System.out.println("--"+L2.get("213-301_4,0-1_9")+"--");
		//apriori.print_dict(L2);    

	}

}
