package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JFileChooser;

import org.jfree.chart.ChartPanel;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXTextArea;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingNode;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;

public class ApplicationController implements Initializable {
    static Instances data;
    Parent root;
	@FXML
	HBox closeButton;
	@FXML
	BorderPane mainPage,preMainPage,miningMainPage,scatterPane,scatterplot2d;
	@FXML
	HBox setting,dataset,att,histogram,boxplot;
	@FXML
	HBox eclatBtn,aprioriBtn;
	//@FXML
	//BorderPane datasetTable;
	@FXML
	Label relationName,instancesNumber,attNumber;
	@FXML
	Label attName,attType;
	@FXML 
	TableView<Statistics> attInfo;
	@FXML
	ChoiceBox attList,attListHist,firstAtt,secondAtt;
	String attribute;
	@FXML TableColumn<Statistics,String> tabStat;
	@FXML TableColumn<Statistics,Double> tabVal;
    int attnum,insnum;
	@FXML
	CategoryAxis histXaxis;
	@FXML
	NumberAxis histYaxis;
	@FXML
	BarChart histChart;
    @FXML
    TextField supportMin,confMin;
    @FXML
    JFXTextArea associations_area;
    @FXML
    JFXButton startAlgo;
    static int algo_index=0;
    public void initialize(URL url, ResourceBundle rb){
        try {     	
		 data = new Instances(new BufferedReader(new FileReader("C:/Users/Lenovo/Desktop/M2-SII-S3 (2019-20)/Data Mining/Data Mining Projet 19-20/HEART_Stat.txt")));
		 attnum=data.numAttributes();
		 insnum=data.numInstances();
		 
        } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    @FXML
	public void close(MouseEvent event){
		 Stage stage = (Stage) closeButton.getScene().getWindow();
		 stage.close();
	 }
    @FXML
	public void preprocessing(MouseEvent event) throws IOException{
		root=FXMLLoader.load(getClass().getResource("DataPreprocessingMain.fxml"));
		mainPage.setCenter(root);
	}
	public void preSetting(MouseEvent event) throws FileNotFoundException, IOException{
		JFileChooser choseFile = new JFileChooser();
		int returnValue=choseFile.showOpenDialog(null);
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			File selectedFile = choseFile.getSelectedFile();
			System.out.println(selectedFile.getAbsolutePath());
			data = new Instances(new BufferedReader(new FileReader(selectedFile.getAbsolutePath())));			
		}
		else{System.out.println("***Error***");}
	 }
	@FXML
	public void preDataSet(MouseEvent event) throws IOException{
		root=FXMLLoader.load(getClass().getResource("DataPreDataset.fxml"));
		preMainPage.setCenter(root);
	    Label relationName = (Label)(preMainPage.lookup("#relationName"));
	    Label instancesNumber = (Label)(preMainPage.lookup("#instancesNumber"));
	    Label attNumber = (Label)(preMainPage.lookup("#attNumber"));
		
		relationName.setText(data.relationName());
	    instancesNumber.setText(String.valueOf(data.numInstances()));
	    attNumber.setText(String.valueOf(data.numAttributes()));
		
	    TableView table = new TableView();
	    ObservableList<Instance> obs=FXCollections.observableArrayList(instances());	
	    table.setItems(obs);
		for(int i=0;i<attnum;i++){
		TableColumn<Instance,String> c1 = new TableColumn<Instance,String>(data.attribute(i).name());
		 final int k=i;
		 c1.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().value(k))));
         table.getColumns().add(c1);
		}			
        BorderPane p = (BorderPane)(preMainPage.lookup("#datasetTable"));
        p.setCenter(table);
	 }
	@FXML
	public void preAttribute(MouseEvent event)throws IOException{
		root=FXMLLoader.load(getClass().getResource("DataPreAttribute.fxml"));
		preMainPage.setCenter(root);
		attList= (ChoiceBox)(preMainPage.lookup("#attList"));
		attInfo= (TableView)(preMainPage.lookup("#attInfo"));
		attName= (Label)(preMainPage.lookup("#attName"));
		attType= (Label)(preMainPage.lookup("#attType"));		
		tabStat= (TableColumn<Statistics, String>)getTableColumnByName(attInfo,"Statistic");
		tabVal= (TableColumn<Statistics, Double>)getTableColumnByName(attInfo,"Value");		
        tabStat.setCellValueFactory(new PropertyValueFactory<Statistics,String>("statName"));
        tabVal.setCellValueFactory(new PropertyValueFactory<Statistics,Double>("statValue"));
		ObservableList<Statistics> obs=FXCollections.observableArrayList();
		for(int i=0;i<attnum;i++)
		    attList.getItems().add(data.attribute(i).name());
	    	attList.getSelectionModel().selectedItemProperty().addListener((v,oldValue,newValue)->{
	    	obs.clear();
			Attribute attribute=data.attribute(newValue.toString());
			String type;
			if(attribute.isNominal()){type="Nominal";}
			else{type="Numeric";}
			attName.setText(attribute.name());
			attType.setText(type);
			addToObs(obs,attribute);
			attInfo.setItems(obs);			
		});				
	 }
	

	@FXML
	public void preBoxPlot(MouseEvent event)throws IOException{
		root=FXMLLoader.load(getClass().getResource("DataPreBoxplot.fxml"));
		preMainPage.setCenter(root);
		BorderPane p= (BorderPane)(preMainPage.lookup("#boxplotAria"));
	    final SwingNode chartSwingNode = new SwingNode();
	    ChartPanel chartPanel=new ChartPanel(BoxPlotChart.generateBoxPlotChart(data));
        //chartPanel.setMaximumDrawWidth(200);  
        //chartPanel.setMaximumDrawHeight(200);
	    //chartPanel.setPreferredSize(new Dimension(200,200));
	    chartSwingNode.setContent(chartPanel);
	    p.setCenter(new StackPane(chartSwingNode));
	 }
	
	public void BoxplotNextBtn(){
		BoxPlotChart.BoxplotNext(data);
	}
	public void BoxplotPrevBtn(){
		BoxPlotChart.BoxplotPrev(data);
	}
	
	@FXML
	public void preHist(MouseEvent event)throws IOException{
		root=FXMLLoader.load(getClass().getResource("DataPreHist.fxml"));
		preMainPage.setCenter(root);
		histChart= (BarChart)(preMainPage.lookup("#histChart"));
		histXaxis= (CategoryAxis)(preMainPage.lookup("#histXaxis"));
		histYaxis= (NumberAxis)(preMainPage.lookup("#histYaxis"));
		histYaxis.setLabel("Frequency");
		
		attListHist= (ChoiceBox)(preMainPage.lookup("#attListHist"));
		for(int i=0;i<attnum;i++) attListHist.getItems().add(data.attribute(i).name());
	    	attListHist.getSelectionModel().selectedItemProperty().addListener((v,oldValue,newValue)->{
	    	histChart.getData().clear();
			Attribute attribute=data.attribute(newValue.toString());
			histXaxis.setLabel(attribute.name());
			histChart.getData().addAll(HistChart.createHist(data, attribute.index()));

		});				
	 }
	
	@FXML
	public void preScatterPlot(MouseEvent event)throws IOException{
		root=FXMLLoader.load(getClass().getResource("DataPreScatterPlot.fxml"));
		preMainPage.setCenter(root);
		scatterPane=(BorderPane)(preMainPage.lookup("#scatterPane"));
        ScrollPane scrollPane=new ScrollPane();
		GridPane scatterMatrix=new GridPane();
		scatterMatrix.setPadding(new Insets(10));
		scatterMatrix.setFocusTraversable(false);
		int n=attnum-1;
		for(int i=0;i<4;i++){
			for(int j=0;j<4;j++){
		        ScatterChart scr=createScaterPlot(i,j);
		        GridPane.setConstraints(scr, j, i);
	        	scatterMatrix.getChildren().addAll(scr);
			}
		}
		scrollPane.setContent(scatterMatrix);
		scatterPane.setCenter(scrollPane);
	}
	
	@FXML
	public void preScatterMatrix(MouseEvent event)throws IOException{
		scatterPane=(BorderPane)(preMainPage.lookup("#scatterPane"));
		if (scatterPane==null) System.out.println("*******************************");
        ScrollPane scrollPane=new ScrollPane();
		GridPane scatterMatrix=new GridPane();
		scatterMatrix.setPadding(new Insets(10));
		scatterMatrix.setFocusTraversable(false);
		int n=attnum-1;
		for(int i=0;i<2;i++){
			for(int j=0;j<2;j++){
		        ScatterChart scr=createScaterPlot(i,j);
		        GridPane.setConstraints(scr, j, i);
	        	scatterMatrix.getChildren().addAll(scr);
			}
		}
		scrollPane.setContent(scatterMatrix);
		scatterPane.setCenter(scrollPane);
	}
	
	@FXML
	public void preScatter2d(MouseEvent event)throws IOException{		
		scatterPane=(BorderPane)(preMainPage.lookup("#scatterPane")); 
		root=FXMLLoader.load(getClass().getResource("scatterplot.fxml"));
		scatterPane.setCenter(root);
		scatterplot2d=(BorderPane)(preMainPage.lookup("#scatterplot2d")); 
		GridPane scatterMatrix=new GridPane();
		scatterMatrix.setPadding(new Insets(10));
		scatterMatrix.setFocusTraversable(false);
		int n=attnum-1;
		firstAtt= (ChoiceBox)(preMainPage.lookup("#firstAtt"));
		secondAtt= (ChoiceBox)(preMainPage.lookup("#secondAtt"));
		for(int i=0;i<attnum;i++) firstAtt.getItems().add(data.attribute(i).name());
		for(int i=0;i<attnum;i++) secondAtt.getItems().add(data.attribute(i).name());
		firstAtt.getSelectionModel().selectedItemProperty().addListener((v,oldValue,newValue)->{
			Attribute attribute1=data.attribute(newValue.toString());
			Attribute attribute2=data.attribute(secondAtt.getSelectionModel().getSelectedItem().toString());
			ScatterChart scr=createScaterPlot(attribute1.index(),attribute2.index());
			 GridPane.setConstraints(scr, 0, 0);
			 scatterMatrix.getChildren().addAll(scr);
		});		
		secondAtt.getSelectionModel().selectedItemProperty().addListener((v,oldValue,newValue)->{
			Attribute attribute1=data.attribute(firstAtt.getSelectionModel().getSelectedItem().toString());
			Attribute attribute2=data.attribute(newValue.toString());
			ScatterChart scr=createScaterPlot(attribute1.index(),attribute2.index());
			 GridPane.setConstraints(scr, 0, 0);
			 scatterMatrix.getChildren().addAll(scr);
		});	
		scatterPane.setCenter(scatterMatrix);
	}
	
	//-------------------------------------------------------------------data mining-----------------------
	@FXML
	public void dataMining(MouseEvent event)throws IOException{
		root=FXMLLoader.load(getClass().getResource("DataMiningMain.fxml"));
		mainPage.setCenter(root);			    
		 	}
	@FXML
	public void miningEclat(MouseEvent event) throws IOException{
		System.out.println("eclaaaaaaaaaat");
		root=FXMLLoader.load(getClass().getResource("DataMiningBtn.fxml"));
		miningMainPage.setCenter(root);
		algo_index=1;
	}
	@FXML
	public void miningApriori(MouseEvent event) throws IOException{
		System.out.println("aprioriiiiiiii");
		root=FXMLLoader.load(getClass().getResource("DataMiningBtn.fxml"));
		miningMainPage.setCenter(root);
		algo_index=0;
	}
	public void addToObs(ObservableList obs,Attribute attribute){
		if(attribute.isNominal()){
			obs.addAll(new Statistics("absent",100),new Statistics("present",102));			
		}
		else{
			obs.addAll(new Statistics("Minimum",min(attribute)),new Statistics("Maximum",max(attribute)),
					new Statistics("Mean",mean(attribute)),new Statistics("Median",median(attribute)),new Statistics("Mode",mode(attribute)),
					new Statistics("variance",variance(attribute)),new Statistics("StdDiv",stdDiv(attribute)));			
		}
	}
	@FXML
	public void startMining() throws IOException{
		System.out.println("**********");
		 int supportMinNb=Integer.parseInt(supportMin.getText());
		 double confMinNb=Double.parseDouble(confMin.getText());
		
		 System.out.println("those are the results: ");
	     System.out.println("supmin= "+supportMinNb+" ,confmin= "+confMinNb);
	if(algo_index==1){//eclat:
		Eclat_4_att eclat=null;
        try {
            eclat= new Eclat_4_att(supportMinNb,confMinNb,data);
            eclat.ECLAT();
            associations_area.setText(eclat.print_all_association());
        }catch (Exception  e) { 
        	eclat.save_itemsets_struct(eclat.getL());       	
        }
	}
	else{//apriori:
		Apriori_4_att apriori=null;
        try {
            //Apriori(int min_support, double min_confidence,int max_set_size,int nb_condidates,int ass_cond,Instances data)
             apriori=new Apriori_4_att(supportMinNb,confMinNb,data);
   		     apriori.Apriori();
   		     associations_area.setText(apriori.print_all_association());
        }catch (Exception  e) { 
        	apriori.save_itemsets_struct(apriori.getL());       	
        }
	}
	
	}
	
	private <T> TableColumn<T, ?> getTableColumnByName(TableView<T> tableView, String name) {
	    for (TableColumn<T, ?> col : tableView.getColumns())
	        if (col.getText().equals(name)) return col ;
	    return null ;
	}
    public double mean(Attribute a){
        double mean=data.meanOrMode(a);
        return mean;
    }
    public double variance(Attribute a){
        double var=data.variance(a);
        return var;
    }
    public double stdDiv(Attribute a){
        double std=Math.sqrt(variance(a));
        return std;
    }
    public double median(Attribute a) {
    	double[] values=data.attributeToDoubleArray(a.index());
        // sort array
        Arrays.sort(values);
        double median;
        // get count of scores
        int totalElements = values.length;
        // check if total number of scores is even
        if (totalElements % 2 == 0) {
            double sumOfMiddleElements = values[totalElements / 2] +
                    values[totalElements / 2 - 1];
            // calculate average of middle elements
            median = ((double) sumOfMiddleElements) / 2;
        } else {
            // get the middle element
            median = (double) values[values.length / 2];
        }
        return median;
    }
    public  double mode(Attribute a){   	
    	double[] values=data.attributeToDoubleArray(a.index());
        int index = 0  ;
        int soFar = 1 ;
        int count = 1 ;
        for(int k =1;   k < values.length; k++){
            if (values[k-1] == values[k]){
                count++ ; }
            if(count > soFar)
            {
                soFar = count ;
                index = k ;
            }
            else {
                count = 1 ;
            }
        }
        return values[index] ;
    }
    
    public double max(Attribute a) {
    	double[] values=data.attributeToDoubleArray(a.index());
        double max = Arrays.stream(values).max().getAsDouble();
        return(max);
    }
    public double min(Attribute a) {
    	double[] values=data.attributeToDoubleArray(a.index());
        double min = Arrays.stream(values).min().getAsDouble();
        return(min);
    }
    public List<Instance> instances(){
    	List<Instance> l=new ArrayList<Instance>();
    	for(int i=0;i<insnum;i++)
    		l.add(data.instance(i));
    	return l;
    }
    public ScatterChart<?,?> createScaterPlot(int att1,int att2){
    	final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        String name1=data.attribute(att1).name();
        String name2=data.attribute(att2).name();
    	ScatterChart<Number,Number> scatterChart=new ScatterChart<Number,Number>(xAxis,yAxis);
    	scatterChart.setId("scatterStyle");
    	xAxis.setLabel(name1);
    	yAxis.setLabel(name2);
    	XYChart.Series series1 = new XYChart.Series();
    	XYChart.Series series2 = new XYChart.Series();
        double[] d1=data.attributeToDoubleArray(att1);
        double[] d2=data.attributeToDoubleArray(att2);
        for(int i=0;i<insnum;i++){
        series1.getData().add(new XYChart.Data(d1[i],d2[i]));
      //  series2.getData().add(new XYChart.Data(d2[i],d2[i]));
        }
        scatterChart.getData().addAll(series1);
        scatterChart.setTitle("ScatterPlot of '"+name1+"' and '"+name2+"'");
    	return (scatterChart);
    }

}
